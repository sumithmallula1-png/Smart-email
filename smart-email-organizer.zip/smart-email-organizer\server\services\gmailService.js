import { google } from 'googleapis';
import { oauth2Client } from '../config/oauth.js';

export async function fetchEmails(tokens, maxResults = 50) {
    oauth2Client.setCredentials(tokens);
    const gmail = google.gmail({ version: 'v1', auth: oauth2Client });

    const response = await gmail.users.messages.list({
        userId: 'me',
        maxResults,
        q: 'in:inbox'
    });

    const messages = response.data.messages || [];
    const emails = [];

    for (const msg of messages.slice(0, 20)) { // Maintaining the slice(0, 20) limit from original code
        try {
            const detail = await gmail.users.messages.get({
                userId: 'me',
                id: msg.id,
                format: 'full' // Changed from 'metadata' to 'full'
            });

            const parsed = parseMessage(detail.data);
            emails.push({
                id: msg.id,
                ...parsed,
                raw: detail.data // Optional: keep raw data if needed for debugging
            });
        } catch (error) {
            console.error(`Failed to fetch message ${msg.id}`, error);
        }
    }

    return emails;
}

export async function getAttachment(tokens, messageId, attachmentId) {
    oauth2Client.setCredentials(tokens);
    const gmail = google.gmail({ version: 'v1', auth: oauth2Client });

    const response = await gmail.users.messages.attachments.get({
        userId: 'me',
        messageId: messageId,
        id: attachmentId
    });

    return response.data;
}

function parseMessage(message) {
    const headers = message.payload.headers || [];
    const getHeader = (name) => headers.find(h => h.name.toLowerCase() === name.toLowerCase())?.value || '';

    const customSubject = getHeader('Subject');
    const from = getHeader('From');
    const date = getHeader('Date');

    let body = '';
    let attachments = [];

    // Recursive function to traverse mime parts
    function traverse(part) {
        if (part.mimeType === 'text/html' && part.body && part.body.data) {
            body = Buffer.from(part.body.data, 'base64').toString('utf-8');
        } else if (part.mimeType === 'text/plain' && !body && part.body && part.body.data) {
            // Fallback to text/plain if no html found yet
            body = Buffer.from(part.body.data, 'base64').toString('utf-8');
        }

        if (part.filename && part.body && part.body.attachmentId) {
            attachments.push({
                filename: part.filename,
                mimeType: part.mimeType,
                attachmentId: part.body.attachmentId,
                size: part.body.size
            });
        }

        if (part.parts) {
            part.parts.forEach(traverse);
        }
    }

    traverse(message.payload);

    return {
        id: message.id,
        threadId: message.threadId,
        snippet: message.snippet,
        subject: customSubject,
        from,
        date,
        body: body || message.snippet, // Fallback to snippet if no body found
        attachments
    };
}
