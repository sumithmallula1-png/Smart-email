import Groq from 'groq-sdk';
import dotenv from 'dotenv';

dotenv.config();

const groq = new Groq({
    apiKey: process.env.GROQ_API_KEY
});

const CATEGORIES = ['Events', 'Workshops', 'Hackathons', 'Professor', 'Personal', 'Spam'];

export async function classifyEmail(email) {
    try {
        const prompt = `Classify this email into exactly one category.

Categories: ${CATEGORIES.join(', ')}

Email:
From: ${email.from}
Subject: ${email.subject}
Preview: ${email.snippet?.substring(0, 200)}

Respond with ONLY the category name, nothing else.`;

        const completion = await groq.chat.completions.create({
            messages: [{ role: 'user', content: prompt }],
            model: 'llama-3.3-70b-versatile',
            temperature: 0.1,
            max_tokens: 20
        });

        const category = completion.choices[0]?.message?.content?.trim();
        return CATEGORIES.includes(category) ? category : 'Personal';
    } catch (error) {
        console.error('Classification error:', error);
        return 'Personal';
    }
}

export async function classifyEmails(emails) {
    const classified = [];
    for (const email of emails) {
        const category = await classifyEmail(email);
        classified.push({ ...email, category });
    }
    return classified;
}
