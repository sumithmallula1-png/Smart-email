import express from 'express';
import Groq from 'groq-sdk';
import dotenv from 'dotenv';

dotenv.config();

const router = express.Router();

const groq = new Groq({
    apiKey: process.env.GROQ_API_KEY
});

const SYSTEM_PROMPT = `You are a helpful AI assistant for the Smart Email Organizer app. You help university students manage emails.

Your capabilities:
- Answer questions about email management
- Explain email categories (Events, Workshops, Hackathons, Professor, Personal, Spam)
- Provide productivity tips for students
- Summarize or explain concepts

Be friendly, concise, helpful. Use emojis occasionally. Keep responses under 150 words.`;

router.post('/', async (req, res) => {
    try {
        const { message } = req.body;

        if (!message) {
            return res.status(400).json({ error: 'Message is required' });
        }

        const completion = await groq.chat.completions.create({
            messages: [
                { role: 'system', content: SYSTEM_PROMPT },
                { role: 'user', content: message }
            ],
            model: 'llama-3.3-70b-versatile',
            temperature: 0.7,
            max_tokens: 500
        });

        const reply = completion.choices[0]?.message?.content || "I couldn't generate a response.";
        res.json({ reply });
    } catch (error) {
        console.error('Chat error:', error);
        res.status(500).json({ error: 'Failed to process chat' });
    }
});

export default router;
