import { logout } from '../services/api';
import { useNavigate } from 'react-router-dom';

export default function Sidebar({ user }) {
    const navigate = useNavigate();

    const handleLogout = async () => {
        await logout();
        navigate('/login');
    };

    return (
        <aside className="sidebar">
            <div className="sidebar__logo">
                <div className="sidebar__logo-icon">📧</div>
                <span className="sidebar__logo-text">Email Organizer</span>
            </div>

            <nav className="sidebar__nav">
                <a href="/dashboard" className="sidebar__nav-item active">
                    <span className="sidebar__nav-item-icon">📊</span>
                    Dashboard
                </a>
                <a href="/dashboard?demo=true" className="sidebar__nav-item">
                    <span className="sidebar__nav-item-icon">🎨</span>
                    Demo Mode
                </a>
            </nav>

            <div className="sidebar__footer">
                {user ? (
                    <div className="sidebar__user">
                        <div className="sidebar__user-avatar" style={{
                            width: 36, height: 36, borderRadius: '50%',
                            background: 'linear-gradient(135deg, #667EEA 0%, #764BA2 100%)',
                            display: 'flex', alignItems: 'center', justifyContent: 'center',
                            color: 'white', fontWeight: 600
                        }}>
                            {user.name?.[0]?.toUpperCase() || 'U'}
                        </div>
                        <div className="sidebar__user-info">
                            <div className="sidebar__user-name">{user.name}</div>
                            <div className="sidebar__user-email">{user.email}</div>
                        </div>
                    </div>
                ) : (
                    <button className="sidebar__nav-item" onClick={() => navigate('/login')}>
                        <span className="sidebar__nav-item-icon">🔐</span>
                        Sign In
                    </button>
                )}
                {user && (
                    <button className="sidebar__nav-item" onClick={handleLogout} style={{ marginTop: '0.5rem' }}>
                        <span className="sidebar__nav-item-icon">🚪</span>
                        Logout
                    </button>
                )}
            </div>
        </aside>
    );
}
