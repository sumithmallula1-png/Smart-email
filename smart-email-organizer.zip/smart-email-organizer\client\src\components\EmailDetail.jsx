export default function EmailDetail({ email }) {
    if (!email) {
        return (
            <div className="email-detail">
                <div className="empty-state">
                    <div className="empty-state__icon">📬</div>
                    <p className="empty-state__text">Select an email to view details</p>
                </div>
            </div>
        );
    }

    const senderName = email.from?.split('<')[0]?.trim() || email.from || 'Unknown';
    const senderEmail = email.from?.match(/<(.+)>/)?.[1] || email.from || '';

    return (
        <div className="email-detail">
            <div className="email-detail__header">
                <h2 className="email-detail__subject">{email.subject}</h2>
                <div className="email-detail__meta">
                    <div className="email-detail__sender">
                        <div className="email-detail__avatar">
                            {senderName.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase()}
                        </div>
                        <div>
                            <div style={{ fontWeight: 600 }}>{senderName}</div>
                            <div style={{ fontSize: '0.875rem', color: '#64748B' }}>{senderEmail}</div>
                        </div>
                    </div>
                    {email.date && (
                        <div className="email-detail__date">
                            {new Date(email.date).toLocaleString()}
                        </div>
                    )}
                </div>
            </div>

            <div className="email-detail__content">
                {/* HTML Body */}
                <div
                    className="email-detail__body"
                    dangerouslySetInnerHTML={{ __html: email.body || email.snippet }}
                />

                {/* Attachments Section */}
                {email.attachments && email.attachments.length > 0 && (
                    <div className="email-detail__attachments">
                        <h3 className="attachments-title">
                            📎 Attachments ({email.attachments.length})
                        </h3>
                        <div className="attachments-list">
                            {email.attachments.map((att, idx) => (
                                <a
                                    key={idx}
                                    href={`/api/emails/${email.id}/attachments/${att.attachmentId}`}
                                    className="attachment-item"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                >
                                    <div className="attachment-icon">
                                        {att.mimeType.includes('image') ? '🖼️' :
                                            att.mimeType.includes('pdf') ? '📄' : '📁'}
                                    </div>
                                    <div className="attachment-info">
                                        <div className="attachment-name">{att.filename}</div>
                                        <div className="attachment-size">
                                            {(att.size / 1024).toFixed(1)} KB
                                        </div>
                                    </div>
                                </a>
                            ))}
                        </div>
                    </div>
                )}
            </div>

            {email.category && (
                <div style={{ marginTop: '1.5rem', borderTop: '1px solid #e2e8f0', paddingTop: '1rem' }}>
                    <span className={`email-item__category ${email.category.toLowerCase()}`}>
                        {email.category}
                    </span>
                </div>
            )}
        </div>
    );
}
