import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import Sidebar from '../components/Sidebar';
import CategoryCard from '../components/CategoryCard';
import EmailList from '../components/EmailList';
import EmailDetail from '../components/EmailDetail';
import ChatBot from '../components/ChatBot';
import { getCurrentUser, getEmails } from '../services/api';

const CATEGORIES = ['Events', 'Workshops', 'Hackathons', 'Professor', 'Personal', 'Spam'];

const DEMO_EMAILS = [
    { id: '1', subject: 'Tech Fest 2026 - Register Now!', snippet: 'Join us for the biggest tech fest of the year with workshops, competitions, and more!', from: 'Events Team <events@university.edu>', date: new Date().toISOString(), category: 'Events' },
    { id: '2', subject: 'Python Workshop - Advanced Topics', snippet: 'Learn advanced Python concepts including decorators, generators, and async programming.', from: 'CS Department <workshops@cs.university.edu>', date: new Date().toISOString(), category: 'Workshops' },
    { id: '3', subject: 'HackathonX 2026 - 48 Hours of Innovation', snippet: 'The annual hackathon is here! Form your teams and build something amazing.', from: 'HackathonX <hack@university.edu>', date: new Date().toISOString(), category: 'Hackathons' },
    { id: '4', subject: 'Assignment 3 Deadline Extended', snippet: 'Due to multiple requests, I am extending the deadline to next Monday at 11:59 PM.', from: 'Prof. Sarah Johnson <s.johnson@university.edu>', date: new Date().toISOString(), category: 'Professor' },
    { id: '5', subject: 'Weekend plans?', snippet: 'Hey! Are you free this weekend? Thinking of organizing a group study session.', from: 'Alex Chen <alex.chen@gmail.com>', date: new Date().toISOString(), category: 'Personal' },
    { id: '6', subject: '🎉 50% OFF - Limited Time Only!', snippet: 'Exclusive student discount on all courses! Use code STUDENT50 at checkout.', from: 'PromoDeals <noreply@promos.com>', date: new Date().toISOString(), category: 'Spam' },
    { id: '7', subject: 'Cultural Night - Performances & Food', snippet: 'Celebrate diversity at our annual cultural night featuring performances from 15 countries.', from: 'Student Council <council@university.edu>', date: new Date().toISOString(), category: 'Events' },
    { id: '8', subject: 'Machine Learning Bootcamp', snippet: 'A 3-day intensive bootcamp covering neural networks, deep learning, and practical applications.', from: 'AI Club <aiclub@university.edu>', date: new Date().toISOString(), category: 'Workshops' },
];

function getDemoData() {
    const grouped = CATEGORIES.reduce((acc, category) => {
        acc[category] = DEMO_EMAILS.filter(e => e.category === category);
        return acc;
    }, {});
    return { emails: DEMO_EMAILS, grouped };
}

export default function Dashboard() {
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const isDemo = searchParams.get('demo') === 'true';

    const [user, setUser] = useState(isDemo ? { name: 'Demo User', email: 'demo@university.edu' } : null);
    const [loading, setLoading] = useState(!isDemo);
    const [emailData, setEmailData] = useState(isDemo ? getDemoData() : { emails: [], grouped: {} });
    const [selectedCategory, setSelectedCategory] = useState(null);
    const [selectedEmail, setSelectedEmail] = useState(null);

    useEffect(() => {
        if (isDemo) return;

        const checkAuth = async () => {
            try {
                const { user, isAuthenticated } = await getCurrentUser();
                if (!isAuthenticated) {
                    navigate('/login');
                    return;
                }
                setUser(user);
                const data = await getEmails();
                setEmailData(data);
            } catch (error) {
                console.error('Auth check failed:', error);
                navigate('/login');
            } finally {
                setLoading(false);
            }
        };
        checkAuth();
    }, [navigate, isDemo]);

    const handleBackToCategories = () => {
        setSelectedCategory(null);
        setSelectedEmail(null);
    };

    if (loading) {
        return (
            <div className="app-layout">
                <Sidebar user={null} />
                <main className="main-content">
                    <div className="loading"><div className="loading__spinner" /></div>
                </main>
            </div>
        );
    }

    const displayEmails = selectedCategory ? emailData.grouped[selectedCategory] || [] : emailData.emails;

    return (
        <div className="app-layout">
            <Sidebar user={user} />
            <main className="main-content">
                <header className="dashboard-header">
                    <h1 className="dashboard-header__title">
                        {selectedCategory ? (
                            <>
                                <button onClick={handleBackToCategories} className="back-btn">←</button>
                                {selectedCategory}
                            </>
                        ) : 'Email Dashboard'}
                    </h1>
                    <p className="dashboard-header__subtitle">
                        {selectedCategory
                            ? `${displayEmails.length} emails in this category`
                            : `Welcome back, ${user?.name?.split(' ')[0] || 'there'}! You have ${emailData.emails.length} emails organized.`}
                    </p>
                    {isDemo && (
                        <div className="demo-badge">🎨 Demo Mode - Showing sample data</div>
                    )}
                </header>

                {!selectedCategory && (
                    <div className="bento-grid">
                        {CATEGORIES.map((category) => (
                            <CategoryCard
                                key={category}
                                category={category}
                                emails={emailData.grouped[category] || []}
                                onClick={() => setSelectedCategory(category)}
                            />
                        ))}
                    </div>
                )}

                {selectedCategory && (
                    <div className="email-section">
                        <EmailList
                            emails={displayEmails}
                            selectedEmail={selectedEmail}
                            onSelectEmail={setSelectedEmail}
                            title={selectedCategory}
                        />
                        <EmailDetail email={selectedEmail} />
                    </div>
                )}

                {!selectedCategory && emailData.emails.length > 0 && (
                    <>
                        <h2 style={{ marginBottom: '1.5rem' }}>Recent Emails</h2>
                        <div className="email-section">
                            <EmailList
                                emails={emailData.emails.slice(0, 10)}
                                selectedEmail={selectedEmail}
                                onSelectEmail={setSelectedEmail}
                                title="All Categories"
                            />
                            <EmailDetail email={selectedEmail} />
                        </div>
                    </>
                )}
            </main>
            <ChatBot />
        </div>
    );
}
