import express from 'express';
import { fetchEmails } from '../services/gmailService.js';
import { classifyEmails } from '../services/classifierService.js';

const router = express.Router();

router.get('/emails', async (req, res) => {
    if (!req.session.tokens) {
        return res.status(401).json({ error: 'Not authenticated' });
    }

    try {
        const emails = await fetchEmails(req.session.tokens);
        const classified = await classifyEmails(emails);

        const grouped = classified.reduce((acc, email) => {
            if (!acc[email.category]) acc[email.category] = [];
            acc[email.category].push(email);
            return acc;
        }, {});

        res.json({ emails: classified, grouped });
    } catch (error) {
        console.error('Email fetch error:', error);
        res.status(500).json({ error: 'Failed to fetch emails' });
    }
});

router.get('/emails/:category', async (req, res) => {
    if (!req.session.tokens) {
        return res.status(401).json({ error: 'Not authenticated' });
    }

    try {
        const emails = await fetchEmails(req.session.tokens);
        const classified = await classifyEmails(emails);
        const filtered = classified.filter(e => e.category === req.params.category);
        res.json({ emails: filtered });
    } catch (error) {
        console.error('Email fetch error:', error);
        res.status(500).json({ error: 'Failed to fetch emails' });
    }
});

router.get('/emails/:messageId/attachments/:attachmentId', async (req, res) => {
    if (!req.session.tokens) {
        return res.status(401).json({ error: 'Not authenticated' });
    }

    try {
        const { messageId, attachmentId } = req.params;
        // Import getAttachment safely or assume it's available in scope if we update imports
        const { getAttachment } = await import('../services/gmailService.js');
        const attachment = await getAttachment(req.session.tokens, messageId, attachmentId);

        const data = Buffer.from(attachment.data, 'base64');

        res.writeHead(200, {
            'Content-Type': 'application/octet-stream', // content-type isn't always returned by the attachment endpoint, might need to pass it or guess it
            'Content-Length': data.length
        });
        res.end(data);
    } catch (error) {
        console.error('Attachment fetch error:', error);
        res.status(500).json({ error: 'Failed to fetch attachment' });
    }
});

export default router;
